import React, { useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  TextInput, 
  TouchableOpacity, 
  StyleSheet, 
  Modal, 
  Platform, 
  Alert 
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import DraggableFlatList, { ScaleDecorator } from 'react-native-draggable-flatlist';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import * as DocumentPicker from 'expo-document-picker';
import * as Sharing from 'expo-sharing';
import * as FileSystem from 'expo-file-system';

// Helper for Persian numbers
const toPersianNums = (n) => {
  const farsiDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
  return n.toString().replace(/\d/g, (x) => farsiDigits[x]);
};

export default function CentersScreen() {
  const [centers, setCenters] = useState([]);
  const [newCenter, setNewCenter] = useState('');
  const [modalVisible, setModalVisible] = useState(false);
  const [selectedIndex, setSelectedIndex] = useState(null);
  const router = useRouter();

  const STORAGE_KEY = 'inperson_centers';

  useEffect(() => { loadCenters(); }, []);

  const loadCenters = async () => {
    const saved = await AsyncStorage.getItem(STORAGE_KEY);
    if (saved) setCenters(JSON.parse(saved));
  };

  const saveCenters = async (newList) => {
    setCenters(newList);
    await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(newList));
  };

  const addCenter = () => {
    if (newCenter.trim() === '') return;
    const newList = [...centers, newCenter.trim()];
    saveCenters(newList);
    setNewCenter('');
  };

  const confirmDelete = (index) => {
    setSelectedIndex(index);
    setModalVisible(true);
  };

  const deleteCenter = () => {
    const newList = centers.filter((_, i) => i !== selectedIndex);
    saveCenters(newList);
    setModalVisible(false);
  };

  const onDragEnd = ({ data }) => {
    saveCenters(data);
  };

  // --- IMPORT / EXPORT LOGIC ---

  const exportCenters = async () => {
    try {
      const fileName = `centers_config_${Date.now()}.json`;
      const fileUri = FileSystem.documentDirectory + fileName;
      
      await FileSystem.writeAsStringAsync(fileUri, JSON.stringify(centers), {
        encoding: FileSystem.EncodingType.UTF8,
      });

      if (await Sharing.isAvailableAsync()) {
        await Sharing.shareAsync(fileUri);
        // Show exact path as requested
        Alert.alert("فایل آماده شد", `مسیر فایل:\n${fileUri}`);
      }
    } catch (e) {
      Alert.alert("خطا", "استخراج لیست با خطا مواجه شد.");
    }
  };

  const importCenters = async () => {
    try {
      const result = await DocumentPicker.getDocumentAsync({
        type: 'application/json',
      });

      if (!result.canceled) {
        const fileContent = await FileSystem.readAsStringAsync(result.assets[0].uri);
        const importedList = JSON.parse(fileContent);

        if (Array.isArray(importedList)) {
          Alert.alert(
            "جایگزینی لیست",
            `آیا مطمئن هستید؟ ${toPersianNums(importedList.length)} مرکز جایگزین لیست فعلی خواهند شد.`,
            [
              { text: "لغو", style: "cancel" },
              { text: "تایید و جایگزینی", onPress: () => saveCenters(importedList) }
            ]
          );
        }
      }
    } catch (e) {
      Alert.alert("خطا", "فایل نامعتبر است.");
    }
  };

  const renderItem = ({ item, drag, isActive, getIndex }) => {
    const index = getIndex();
    return (
      <ScaleDecorator>
        <TouchableOpacity
          activeOpacity={1}
          onLongPress={drag}
          disabled={isActive}
          style={[
            styles.centerItem,
            { backgroundColor: isActive ? '#f1f2f6' : '#fff', elevation: isActive ? 10 : 2 }
          ]}
        >
          <TouchableOpacity onPress={() => confirmDelete(index)} style={styles.deleteBtn}>
            <Ionicons name="trash-outline" size={26} color="#e74c3c" />
          </TouchableOpacity>

          <View style={styles.centerNameContainer}>
            <Text style={styles.centerText} numberOfLines={1}>{item}</Text>
          </View>

          <TouchableOpacity onPressIn={drag} style={styles.dragHandle}>
            <Ionicons name="reorder-three-outline" size={32} color="#bdc3c7" />
          </TouchableOpacity>
        </TouchableOpacity>
      </ScaleDecorator>
    );
  };

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <View style={styles.container}>
        <View style={styles.header}>
          <Text style={styles.title}>مدیریت گنجه‌ها</Text>
          <TouchableOpacity 
            onPress={() => router.back()} 
            style={styles.topRightBackButton}
            activeOpacity={0.7}
          >
            <Ionicons name="chevron-forward" size={35} color="#fff" />
          </TouchableOpacity>
        </View>
        
        <View style={styles.content}>
          <View style={styles.inputRow}>
            <TouchableOpacity style={styles.addButton} onPress={addCenter}>
              <Text style={styles.addButtonText}>اضافه</Text>
            </TouchableOpacity>
            <TextInput 
              style={styles.input} 
              placeholder="نام گنجه جدید..." 
              placeholderTextColor="#bdc3c7"
              value={newCenter}
              onChangeText={setNewCenter}
            />
          </View>

          <DraggableFlatList
            data={centers}
            onDragEnd={onDragEnd}
            keyExtractor={(item, index) => `center-${index}`}
            renderItem={renderItem}
            contentContainerStyle={{ paddingBottom: 120 }} // Room for bottom buttons
          />
        </View>

        {/* NEW BOTTOM ACTION BAR */}
        <View style={styles.bottomActionBar}>
          <TouchableOpacity style={styles.actionBtn} onPress={exportCenters}>
            <Ionicons name="share-outline" size={24} color="#17479e" />
            <Text style={styles.actionBtnText}>خروجی</Text>
          </TouchableOpacity>

          <TouchableOpacity style={[styles.actionBtn, {backgroundColor: '#17479e'}]} onPress={importCenters}>
            <Ionicons name="download-outline" size={24} color="#fff" />
            <Text style={[styles.actionBtnText, {color: '#fff'}]}>ورود لیست</Text>
          </TouchableOpacity>
        </View>

        <Modal transparent={true} visible={modalVisible} animationType="fade">
          <View style={styles.modalOverlay}>
            <View style={styles.modalContent}>
              <Text style={styles.modalTitle}>حذف گنجه</Text>
              <Text style={styles.modalBody}>آیا از حذف این گنجه مطمئن هستید؟</Text>
              
              <View style={styles.modalButtons}>
                <TouchableOpacity style={[styles.mBtn, styles.mDelete]} onPress={deleteCenter}>
                  <Text style={styles.mBtnText}>حذف نهایی</Text>
                </TouchableOpacity>
                <TouchableOpacity style={[styles.mBtn, styles.mCancel]} onPress={() => setModalVisible(false)}>
                  <Text style={[styles.mBtnText, {color: '#7f8c8d'}]}>لغو</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        </Modal>
      </View>
    </GestureHandlerRootView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f8f9fa' },
  header: { 
    height: 140, 
    backgroundColor: '#17479e', 
    justifyContent: 'center', 
    alignItems: 'center', 
    paddingTop: 40, 
    borderBottomRightRadius: 40, 
    borderBottomLeftRadius: 40,
    elevation: 8,
    position: 'relative', 
  },
  title: { fontSize: 26, fontFamily: 'IRANSans', color: '#fff' },
  topRightBackButton: { 
    position: 'absolute', 
    right: 20, 
    top: 65, 
    padding: 5,
    zIndex: 10 
  },
  
  content: { flex: 1, padding: 25 },
  inputRow: { 
    flexDirection: 'row', 
    marginBottom: 30, 
    alignItems: 'center', 
    backgroundColor: '#fff', 
    borderRadius: 15, 
    paddingHorizontal: 10, 
    elevation: 2,
    direction: 'ltr' // Keeps the button on the left, input on the right
  },
  input: { 
    flex: 1, 
    paddingVertical: 18, 
    textAlign: 'right', 
    fontFamily: 'IRANSans', 
    fontSize: 20 
  },
  addButton: { 
    backgroundColor: '#f0b619', 
    paddingVertical: 12, 
    paddingHorizontal: 25, 
    borderRadius: 12 
  },
  addButtonText: { color: '#17479e', fontFamily: 'IRANSans', fontSize: 18 },
  
  centerItem: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    padding: 15, 
    backgroundColor: '#fff', 
    borderRadius: 15, 
    marginBottom: 12, 
    elevation: 2,
    direction: 'ltr'
  },
  centerNameContainer: { flex: 1, paddingHorizontal: 15 },
  centerText: { 
    fontSize: 22, 
    fontFamily: 'IRANSans', 
    color: '#2c3e50', 
    textAlign: 'right' 
  },
  deleteBtn: { padding: 5 },
  dragHandle: { padding: 5, marginLeft: 10 },

  // BOTTOM ACTION BAR STYLES
  bottomActionBar: {
    position: 'absolute',
    bottom: 0,
    width: '100%',
    backgroundColor: '#fff',
    flexDirection: 'row',
    paddingHorizontal: 20,
    paddingTop: 15,
    paddingBottom: Platform.OS === 'ios' ? 35 : 25, // Clear navigation bar
    borderTopWidth: 1,
    borderTopColor: '#ecf0f1',
    justifyContent: 'space-between',
    direction: 'ltr'
  },
  actionBtn: {
    flex: 0.48,
    flexDirection: 'row',
    height: 55,
    borderRadius: 15,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#17479e',
    gap: 8
  },
  actionBtnText: {
    fontFamily: 'IRANSans',
    fontSize: 16,
    color: '#17479e'
  },
  
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.6)', justifyContent: 'center', alignItems: 'center' },
  modalContent: { width: '85%', backgroundColor: '#fff', borderRadius: 25, padding: 30, alignItems: 'flex-end' },
  modalTitle: { fontFamily: 'IRANSans', fontSize: 28, color: '#e74c3c', marginBottom: 15 },
  modalBody: { fontFamily: 'IRANSans', fontSize: 22, color: '#2c3e50', textAlign: 'right', marginBottom: 30 },
  modalButtons: { 
    flexDirection: 'row', 
    width: '100%', 
    justifyContent: 'space-between',
    direction: 'ltr'
  },
  mBtn: { flex: 0.48, paddingVertical: 15, borderRadius: 15, alignItems: 'center' },
  mDelete: { backgroundColor: '#e74c3c' },
  mCancel: { backgroundColor: '#ecf0f1' },
  mBtnText: { fontFamily: 'IRANSans', fontSize: 20, color: '#fff' }
});