import React from 'react';
import { StyleSheet, Text, View, TouchableOpacity, Platform, Linking } from 'react-native';
import { Link } from 'expo-router';
import { I18nManager } from 'react-native';

// Force LTR and prevent mirroring
I18nManager.allowRTL(false);
I18nManager.forceRTL(false);

export default function HomeScreen() {
  
  const openMessenger = () => {
    const url = 'https://eitaa.com/Navid_GHO'; 
    
    Linking.canOpenURL(url).then(supported => {
      if (supported) {
        Linking.openURL(url);
      }
    });
  };

  return (
    <View style={styles.container}>
      {/* Header Area */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>حضوری دیجی اکسپرس</Text>
      </View>

      <View style={styles.menu}>
        {/* MANAGE CENTERS BUTTON */}
        <Link href="/centers" asChild>
          <TouchableOpacity style={styles.button} activeOpacity={0.8}>
            <Text style={styles.buttonText}>گنجه‌ها</Text>
          </TouchableOpacity>
        </Link>

        {/* ARCHIVES BUTTON */}
        <Link href="/archives" asChild>
          <TouchableOpacity style={styles.button} activeOpacity={0.8}>
            <Text style={styles.buttonText}>آرشیوها</Text>
          </TouchableOpacity>
        </Link>
      </View>

      {/* Footer Area */}
      <View style={styles.footer}>
        <Text style={styles.footerText}>
          توسط{' '}
          <Text 
            style={styles.linkText} 
            onPress={openMessenger}
          >
            نوید قریشی
          </Text>
          {' '}از شعبه مشهد
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { 
    flex: 1, 
    backgroundColor: '#ffffff' 
  },
  header: { 
    height: 180, 
    backgroundColor: '#17479e', 
    justifyContent: 'center', 
    alignItems: 'center', 
    paddingTop: 50,
    borderBottomRightRadius: 50,
    borderBottomLeftRadius: 50,
    elevation: 15,
    shadowColor: '#000',
    shadowOpacity: 0.3,
    shadowRadius: 12,
  },
  headerTitle: { 
    color: '#ffffff', 
    fontSize: 34, 
    fontFamily: 'IRANSans', 
    textAlign: 'center',
  },
  menu: { 
    flex: 1, 
    justifyContent: 'center', 
    paddingHorizontal: 30 
  },
  button: { 
    backgroundColor: '#f0b619', 
    paddingVertical: 24, 
    borderRadius: 25, 
    marginBottom: 30, 
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 8,
    shadowColor: '#000',
    shadowOpacity: 0.2,
    shadowRadius: 6,
    borderWidth: 1.5,
    borderColor: '#d9a416', 
  },
  buttonText: { 
    color: '#17479e', 
    fontSize: 35, 
    fontFamily: 'IRANSans', 
    textAlign: 'center',
  },
  footer: { 
    paddingBottom: Platform.OS === 'android' ? 80 : 50, 
    paddingTop: 20,
    alignItems: 'center',
  },
  footerText: { 
    color: '#b2bec3', 
    fontSize: 20, 
    fontFamily: 'BYekan', 
    textAlign: 'center'
  },
  linkText: {
    color: '#17479e', // Navy blue to show it's clickable
    textDecorationLine: 'underline',
  }
});