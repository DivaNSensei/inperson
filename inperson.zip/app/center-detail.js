import React, { useState, useCallback } from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet, Modal, Platform } from 'react-native';
import { useLocalSearchParams, useRouter, useFocusEffect } from 'expo-router';
import { getAllArchives, deleteScan, toPersianNums } from '../utils/storage';
import { Ionicons } from '@expo/vector-icons';

export default function CenterDetailScreen() {
  const { date, centerName } = useLocalSearchParams();
  const [codes, setCodes] = useState([]);
  const [modalVisible, setModalVisible] = useState(false);
  const [selectedCode, setSelectedCode] = useState(null);
  const router = useRouter();

  useFocusEffect(useCallback(() => {
    loadData();
  }, [date, centerName]));

  const loadData = async () => {
    const data = await getAllArchives();
    setCodes(data[date]?.[centerName] || []);
  };

  const goToScanner = () => {
    router.push({
      pathname: '/scanner',
      params: { centerName, date }
    });
  };

  const confirmDelete = (code) => {
    setSelectedCode(code);
    setModalVisible(true);
  };

  const handleDelete = async () => {
    await deleteScan(date, centerName, selectedCode);
    setModalVisible(false);
    loadData();
  };

  return (
    <View style={styles.container}>
      {/* HEADER FIX: Absolute Positioning for Back Button */}
      <View style={styles.header}>
        <View style={styles.headerTextContainer}>
          <Text 
            style={styles.headerTitle} 
            numberOfLines={1} 
            adjustsFontSizeToFit={true}
          >
            {centerName}
          </Text>
          <Text style={styles.headerSub}>{toPersianNums(date)}</Text>
        </View>

        <TouchableOpacity onPress={() => router.back()} style={styles.topRightBackButton}>
          <Ionicons name="chevron-forward" size={35} color="#fff" />
        </TouchableOpacity>
      </View>

      {/* CONTENT */}
      {codes.length === 0 ? (
        <View style={styles.emptyContainer}>
          <View style={styles.emptyIconCircle}>
            <Ionicons name="barcode-outline" size={100} color="#dcdde1" />
          </View>
          <Text style={styles.emptyText}>هنوز هیچ کدی برای این گنجه ثبت نشده است.</Text>
          <TouchableOpacity style={styles.startScanBtn} onPress={goToScanner}>
            <Ionicons name="camera" size={28} color="#17479e" />
            <Text style={styles.startScanText}>شروع اسکن جدید</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <>
          <View style={styles.listHeader}>
             <Text style={styles.listCount}>{toPersianNums(codes.length)} کد ثبت شده</Text>
          </View>
          <FlatList
            data={codes}
            keyExtractor={(item, index) => index.toString()}
            renderItem={({ item }) => (
              <View style={styles.codeRow}>
                <TouchableOpacity onPress={() => confirmDelete(item)} style={styles.deleteBtn}>
                  <Ionicons name="trash-outline" size={26} color="#e74c3c" />
                </TouchableOpacity>
                {/* Monospace for codes to keep them consistent */}
                <Text style={styles.codeText}>{item}</Text>
              </View>
            )}
            contentContainerStyle={{ padding: 20, paddingBottom: 100 }}
          />
          
          {/* FAB FIX: Pinned to Right */}
          <TouchableOpacity style={styles.fabAdd} onPress={goToScanner}>
            <Ionicons name="add" size={40} color="#17479e" />
          </TouchableOpacity>
        </>
      )}

      {/* CUSTOM DELETE MODAL */}
      <Modal transparent={true} visible={modalVisible} animationType="fade">
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>حذف کد</Text>
            <Text style={styles.modalBody}>آیا از حذف کد {selectedCode} مطمئن هستید؟</Text>
            
            <View style={styles.modalButtons}>
              <TouchableOpacity style={[styles.mBtn, styles.mDelete]} onPress={handleDelete}>
                <Text style={styles.mBtnText}>حذف نهایی</Text>
              </TouchableOpacity>
              
              <TouchableOpacity style={[styles.mBtn, styles.mCancel]} onPress={() => setModalVisible(false)}>
                <Text style={[styles.mBtnText, {color: '#7f8c8d'}]}>لغو</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f8f9fa' },
  header: { 
    height: 140,
    backgroundColor: '#17479e', 
    paddingTop: 45, 
    borderBottomRightRadius: 30,
    borderBottomLeftRadius: 30,
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 8,
    position: 'relative'
  },
  headerTextContainer: {
    alignItems: 'center',
    paddingHorizontal: 50, // Leave space for the absolute button
  },
  headerTitle: { 
    fontSize: 24, 
    fontFamily: 'IRANSans', 
    color: '#fff',
    textAlign: 'center',
  },
  headerSub: { 
    fontSize: 16, 
    fontFamily: 'IRANSans', 
    color: '#f0b619',
    textAlign: 'center',
  },
  topRightBackButton: { 
    position: 'absolute',
    right: 20,
    top: 65,
    padding: 5,
    zIndex: 10
  },
  
  listHeader: { paddingHorizontal: 25, paddingTop: 20, alignItems: 'flex-end' },
  listCount: { fontFamily: 'IRANSans', fontSize: 18, color: '#7f8c8d' },

  emptyContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 40 },
  emptyIconCircle: { width: 180, height: 180, borderRadius: 90, backgroundColor: '#fff', justifyContent: 'center', alignItems: 'center', marginBottom: 30, elevation: 2 },
  emptyText: { textAlign: 'center', color: '#7f8c8d', fontSize: 20, fontFamily: 'IRANSans', marginBottom: 40, lineHeight: 30 },
  startScanBtn: { 
    backgroundColor: '#f0b619', 
    flexDirection: 'row', // Force LTR
    paddingVertical: 18, 
    paddingHorizontal: 35, 
    borderRadius: 20, 
    alignItems: 'center', 
    gap: 15, 
    elevation: 5,
    direction: 'ltr'
  },
  startScanText: { color: '#17479e', fontSize: 22, fontFamily: 'IRANSans' },

  codeRow: { 
    flexDirection: 'row', // Trash on left, code on right
    justifyContent: 'space-between', 
    alignItems: 'center', 
    padding: 20, 
    backgroundColor: '#fff',
    borderRadius: 15,
    marginBottom: 12,
    elevation: 2,
    direction: 'ltr'
  },
  codeText: { 
    fontSize: 20, 
    fontFamily: Platform.OS === 'android' ? 'monospace' : 'Courier', 
    color: '#2c3e50', 
    fontWeight: 'bold',
    writingDirection: 'ltr' // Crucial for barcode strings
  },
  deleteBtn: { padding: 5 },
  
  fabAdd: {
    position: 'absolute',
    bottom: Platform.OS === 'android' ? 40 : 30,
    right: 30,
    backgroundColor: '#f0b619',
    width: 70,
    height: 70,
    borderRadius: 35,
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 8,
  },

  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.6)', justifyContent: 'center', alignItems: 'center' },
  modalContent: { width: '85%', backgroundColor: '#fff', borderRadius: 25, padding: 30, alignItems: 'flex-end' },
  modalTitle: { fontFamily: 'IRANSans', fontSize: 28, color: '#e74c3c', marginBottom: 15 },
  modalBody: { fontFamily: 'IRANSans', fontSize: 20, color: '#2c3e50', textAlign: 'right', marginBottom: 30 },
  modalButtons: { 
    flexDirection: 'row', 
    width: '100%', 
    justifyContent: 'space-between',
    direction: 'ltr' 
  },
  mBtn: { flex: 0.48, paddingVertical: 15, borderRadius: 15, alignItems: 'center' },
  mDelete: { backgroundColor: '#e74c3c' },
  mCancel: { backgroundColor: '#ecf0f1' },
  mBtnText: { fontFamily: 'IRANSans', fontSize: 18, color: '#fff' }
});