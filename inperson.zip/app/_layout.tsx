import { useEffect } from 'react';
import { useFonts } from 'expo-font';
import { Stack } from 'expo-router';
import * as SplashScreen from 'expo-splash-screen';
import { ThemeProvider, DefaultTheme } from '@react-navigation/native';
import { I18nManager } from 'react-native';

// Force LTR and prevent mirroring
I18nManager.allowRTL(false);
I18nManager.forceRTL(false);

// Keep the splash screen visible while we fetch resources
SplashScreen.preventAutoHideAsync();

export default function RootLayout() {
  const [loaded, error] = useFonts({
  'IRANSans': require('../assets/fonts/IRANSansBold-Edit.ttf'),
  'BYekan': require('../assets/fonts/BYekan.ttf'),
  });

  useEffect(() => {
    if (loaded || error) {
      SplashScreen.hideAsync();
    }
  }, [loaded, error]);

  if (!loaded && !error) {
    return null;
  }

  return (
    <ThemeProvider value={DefaultTheme}>
      <Stack screenOptions={{ headerShown: false }}>
        <Stack.Screen name="index" />
        <Stack.Screen name="archives" />
        <Stack.Screen name="centers" />
        <Stack.Screen name="daily-session" />
        <Stack.Screen name="center-detail" />
        <Stack.Screen name="scanner" />
      </Stack>
    </ThemeProvider>
  );
}