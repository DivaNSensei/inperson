import React, { useState, useCallback } from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet, Platform, Modal } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useLocalSearchParams, useRouter, useFocusEffect } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { getAllArchives, toPersianNums } from '../utils/storage';
import * as Sharing from 'expo-sharing';

// Using legacy for SDK 54 compatibility
import * as FileSystem from 'expo-file-system/legacy'; 

const { StorageAccessFramework } = FileSystem;

export default function DailySessionScreen() {
  const { date } = useLocalSearchParams();
  const [centers, setCenters] = useState([]);
  const [archiveData, setArchiveData] = useState({});
  const [modalInfo, setModalInfo] = useState({ visible: false, title: '', message: '' });
  const router = useRouter();

  useFocusEffect(useCallback(() => {
    const loadSessionData = async () => {
      // 1. Load the centers in the specific order saved in the management page
      const savedCenters = await AsyncStorage.getItem('inperson_centers');
      const centerList = savedCenters ? JSON.parse(savedCenters) : [];
      setCenters(centerList);

      // 2. Load the actual scan data
      const allData = await getAllArchives();
      setArchiveData(allData[date] || {});
    };
    loadSessionData();
  }, [date]));

  const showInfo = (title, message) => {
    setModalInfo({ visible: true, title, message });
  };

  const generateCSV = () => {
    // FIX: Instead of Object.keys, we use 'centers' to maintain the universal order
    // We only include centers that actually have scans for this specific date
    const centersWithData = centers.filter(c => archiveData[c] && archiveData[c].length > 0);
    
    if (centersWithData.length === 0) return null;

    // Determine the longest list to know how many rows to create
    const maxRows = Math.max(...centersWithData.map(c => archiveData[c]?.length || 0));
    
    // Header row using the ordered names
    let csvContent = centersWithData.join(",") + "\n";
    
    // Data rows
    for (let i = 0; i < maxRows; i++) {
      let row = centersWithData.map(center => {
        const codesForCenter = archiveData[center] || [];
        const code = codesForCenter[i];
        // Ensure commas in data don't break the CSV format
        return code ? String(code).replace(/,/g, '') : ""; 
      });
      csvContent += row.join(",") + "\n";
    }
    return "\ufeff" + csvContent; // UTF-8 BOM for Excel compatibility with Persian names
  };

  const handleLocalSave = async () => {
    const finalOutput = generateCSV();
    if (!finalOutput) {
      return showInfo("خطا", "داده‌ای برای ذخیره وجود ندارد. ابتدا کدها را اسکن کنید.");
    }

    try {
      const safeDate = String(date).replace(/[\/\-]/g, '_');
      const filename = `Hozoori_${safeDate}.csv`;

      if (Platform.OS === 'android') {
        const permissions = await StorageAccessFramework.requestDirectoryPermissionsAsync();
        if (permissions.granted) {
          const fileUri = await StorageAccessFramework.createFileAsync(
            permissions.directoryUri,
            filename,
            'text/csv'
          );
          await FileSystem.writeAsStringAsync(fileUri, finalOutput, { encoding: FileSystem.EncodingType.UTF8 });
          
          showInfo(
            "فایل ذخیره شد", 
            `گزارش با موفقیت در پوشه انتخابی ذخیره شد.\n\nمسیر:\n${decodeURIComponent(fileUri)}`
          );
        } else {
          showInfo("دسترسی رد شد", "برای ذخیره فایل خروجی، تایید دسترسی به پوشه الزامی است.");
        }
      } else {
        const fileUri = FileSystem.cacheDirectory + filename;
        await FileSystem.writeAsStringAsync(fileUri, finalOutput, { encoding: FileSystem.EncodingType.UTF8 });
        await Sharing.shareAsync(fileUri);
      }
    } catch (e) {
      console.error("SAVE_ERROR:", e);
      showInfo("خطا", "مشکلی در فرآیند ذخیره فایل پیش آمد. دوباره تلاش کنید.");
    }
  };

  const handleShare = async () => {
    const finalOutput = generateCSV();
    if (!finalOutput) {
      return showInfo("خطا", "داده‌ای برای اشتراک‌گذاری یافت نشد.");
    }

    try {
      const safeDate = String(date).replace(/[\/\-]/g, '_');
      const filename = `Hozoori_${safeDate}.csv`;
      const fileUri = FileSystem.cacheDirectory + filename;

      await FileSystem.writeAsStringAsync(fileUri, finalOutput, {
        encoding: FileSystem.EncodingType.UTF8,
      });

      const isAvailable = await Sharing.isAvailableAsync();
      if (isAvailable) {
        await Sharing.shareAsync(fileUri, {
          mimeType: 'text/csv',
          dialogTitle: `ارسال گزارش حضوری`,
        });
      } else {
        showInfo("خطا", "سیستم اشتراک‌گذاری در این دستگاه در دسترس نیست.");
      }
    } catch (e) {
      console.error("SHARE_ERROR:", e);
      showInfo("خطا", "فرآیند اشتراک‌گذاری با شکست مواجه شد.");
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <View style={styles.headerTextContainer}>
          <Text style={styles.title}>مدیریت آرشیو</Text>
          <Text style={styles.headerDate}>{"\u200f" + toPersianNums(date)}</Text>
        </View>

        <TouchableOpacity onPress={() => router.back()} style={styles.topRightBackButton}>
          <Ionicons name="chevron-forward" size={35} color="#fff" />
        </TouchableOpacity>
      </View>

      <FlatList
        data={centers} // This uses the order from AsyncStorage automatically
        keyExtractor={(item) => item}
        contentContainerStyle={{ paddingVertical: 20 }}
        renderItem={({ item }) => {
          const count = archiveData[item]?.length || 0;
          return (
            <TouchableOpacity 
              style={styles.card}
              onPress={() => router.push({ pathname: '/center-detail', params: { centerName: item, date: date }})}
            >
              <View style={styles.cardLeft}>
                <Ionicons name="chevron-back" size={20} color="#17479e" style={{ opacity: 0.3 }} />
                <View style={styles.countBadge}>
                  <Text style={styles.countText}>{toPersianNums(count)}</Text>
                </View>
              </View>
              <View style={styles.cardTextContainer}>
                <Text style={styles.cardText}>{item}</Text>
              </View>
            </TouchableOpacity>
          );
        }}
        ListFooterComponent={<View style={{ height: 180 }} />}
      />

      <View style={styles.footer}>
        <TouchableOpacity style={styles.saveBtn} onPress={handleLocalSave}>
          <Ionicons name="save-outline" size={24} color="#17479e" />
          <Text style={styles.btnTextDark}>ذخیره</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.shareBtn} onPress={handleShare}>
          <Ionicons name="share-social-outline" size={24} color="white" />
          <Text style={styles.btnTextLight}>اشتراک گذاری</Text>
        </TouchableOpacity>
      </View>

      <Modal visible={modalInfo.visible} transparent animationType="fade">
        <View style={styles.modalOverlay}>
          <View style={styles.modalBox}>
            <View style={styles.modalHeader}>
                <Ionicons name="information-circle" size={40} color="#f0b619" />
                <Text style={styles.modalTitle}>{modalInfo.title}</Text>
            </View>
            <Text style={styles.modalMessage}>{modalInfo.message}</Text>
            <TouchableOpacity 
                style={styles.modalConfirmBtn} 
                onPress={() => setModalInfo({ ...modalInfo, visible: false })}
            >
              <Text style={styles.modalConfirmText}>متوجه شدم</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f8f9fa' },
  header: { 
    height: 160, 
    backgroundColor: '#17479e', 
    paddingTop: 50, 
    justifyContent: 'center', 
    alignItems: 'center', 
    borderBottomRightRadius: 30, 
    borderBottomLeftRadius: 30, 
    elevation: 10,
    position: 'relative' 
  },
  headerTextContainer: { alignItems: 'center' },
  title: { fontSize: 18, fontFamily: 'IRANSans', color: '#ffffff' },
  headerDate: { fontSize: 26, fontFamily: 'IRANSans', color: '#f0b619', marginTop: 2 },
  topRightBackButton: { 
    position: 'absolute', 
    right: 20, 
    top: 65, 
    padding: 5,
    zIndex: 10 
  },
  card: { 
    backgroundColor: '#fff', 
    marginHorizontal: 20, 
    marginBottom: 12, 
    padding: 18, 
    borderRadius: 20, 
    flexDirection: 'row', 
    alignItems: 'center', 
    elevation: 3 
  },
  cardTextContainer: { flex: 1 },
  cardText: { fontSize: 20, fontFamily: 'IRANSans', color: '#2c3e50', textAlign: 'right' },
  cardLeft: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    gap: 10,
    direction: 'ltr'
  },
  countBadge: { backgroundColor: '#f0b619', paddingHorizontal: 12, paddingVertical: 4, borderRadius: 10 },
  countText: { fontFamily: 'IRANSans', fontSize: 16, color: '#17479e' },
  footer: { 
    position: 'absolute', 
    bottom: 0, 
    width: '100%', 
    backgroundColor: '#fff', 
    paddingBottom: 40, 
    paddingTop: 20, 
    paddingHorizontal: 20, 
    flexDirection: 'row', 
    gap: 12, 
    elevation: 25,
    direction: 'ltr' 
  },
  saveBtn: { flex: 1, backgroundColor: '#f0b619', padding: 18, borderRadius: 18, flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 10 },
  shareBtn: { flex: 1, backgroundColor: '#17479e', padding: 18, borderRadius: 18, flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 10 },
  btnTextDark: { color: '#17479e', fontSize: 16, fontFamily: 'IRANSans' },
  btnTextLight: { color: '#fff', fontSize: 16, fontFamily: 'IRANSans' },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(23, 71, 158, 0.4)', justifyContent: 'center', alignItems: 'center' },
  modalBox: { width: '85%', backgroundColor: '#fff', borderRadius: 30, padding: 25, alignItems: 'center', elevation: 20, borderWidth: 1, borderColor: '#eee' },
  modalHeader: { alignItems: 'center', marginBottom: 15 },
  modalTitle: { fontFamily: 'IRANSans', fontSize: 20, color: '#17479e', marginTop: 10, fontWeight: 'bold' },
  modalMessage: { fontFamily: 'IRANSans', fontSize: 15, color: '#444', textAlign: 'center', marginBottom: 25, lineHeight: 22 },
  modalConfirmBtn: { backgroundColor: '#17479e', paddingHorizontal: 40, paddingVertical: 12, borderRadius: 15, elevation: 5 },
  modalConfirmText: { color: '#f0b619', fontFamily: 'IRANSans', fontSize: 16, fontWeight: 'bold' }
});