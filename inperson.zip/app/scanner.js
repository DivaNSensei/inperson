import React, { useState, useEffect, useRef } from 'react';
import { 
  StyleSheet, 
  Text, 
  View, 
  TouchableOpacity, 
  Platform, 
  Modal, 
  TextInput, 
  KeyboardAvoidingView 
} from 'react-native';
import { CameraView, useCameraPermissions } from 'expo-camera';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { Audio } from 'expo-av';
import { useKeepAwake } from 'expo-keep-awake'; // FIX: Keeps screen from dimming
import { useIsFocused } from '@react-navigation/native'; // FIX: Prevents camera freeze
import { saveScan, toPersianNums, getAllArchives } from '../utils/storage';

const ScannerScreen = () => {
  // 1. Keep the screen awake while this component is mounted
  useKeepAwake();

  const { centerName, date } = useLocalSearchParams();
  const router = useRouter();
  const isFocused = useIsFocused(); // Tracks if the screen is currently visible
  
  const [permission, requestPermission] = useCameraPermissions();
  const [scanned, setScanned] = useState(false);
  const [currentCount, setCurrentCount] = useState(0);
  const [feedback, setFeedback] = useState({ message: '', type: '' });

  // MANUAL ENTRY STATE: Split to handle the "Flexible Suffix"
  const [manualVisible, setManualVisible] = useState(false);
  const [mainCode, setMainCode] = useState(""); // The 9 digits
  const [suffix, setSuffix] = useState("");     // The 1-2 digits after underscore
  const inputRef = useRef(null);
  
  const soundRef = useRef(null);
  const errorSoundRef = useRef(null);

  // THE IRON GATE: DK + exactly 9 digits + underscore + 1 to 2 digits
  const VALID_PATTERN = /^DK\d{9}_\d{1,2}$/;

  useEffect(() => {
    let isMounted = true;

    async function setup() {
      const result = await requestPermission();
      if (!isMounted) return;

      if (!result.granted && result.status !== 'undetermined') {
        router.back();
        return;
      }

      const data = await getAllArchives();
      const existingCodes = data[date]?.[centerName] || [];
      if (isMounted) setCurrentCount(existingCodes.length);

      try {
        await Audio.setAudioModeAsync({
          allowsRecordingIOS: false,
          playsInSilentModeIOS: true,
          shouldDuckAndroid: true,
          staysActiveInBackground: false,
        });

        const { sound: okSound } = await Audio.Sound.createAsync(require("../assets/beep.mp3"));
        soundRef.current = okSound;

        const { sound: errSound } = await Audio.Sound.createAsync(require("../assets/error.mp3"));
        errorSoundRef.current = errSound;
      } catch (e) {
        console.log("Audio Setup Error:", e);
      }
    }

    setup();

    return () => {
      isMounted = false;
      if (soundRef.current) soundRef.current.unloadAsync();
      if (errorSoundRef.current) errorSoundRef.current.unloadAsync();
    };
  }, []);

  // Auto-focus input when modal opens
  useEffect(() => {
    if (manualVisible) {
      const timer = setTimeout(() => inputRef.current?.focus(), 150);
      return () => clearTimeout(timer);
    }
  }, [manualVisible]);

  const playSound = async (type) => {
    try {
      const s = type === 'success' ? soundRef.current : errorSoundRef.current;
      if (s) {
        await s.stopAsync();
        await s.playAsync();
      }
    } catch (e) {
      console.log("Playback error", e);
    }
  };

  const triggerFeedback = (msg, type) => {
    setFeedback({ message: msg, type });
    playSound(type);
    setTimeout(() => setFeedback({ message: '', type: '' }), 1800);
  };

  const processScan = async (data) => {
    if (scanned) return;

    // REPLACED: Strict Regex check instead of just .startsWith("DK")
    if (!VALID_PATTERN.test(data)) {
      setScanned(true);
      triggerFeedback("کد ناقص یا اشتباه است", "error");
      setTimeout(() => setScanned(false), 2000);
      return;
    }

    setScanned(true);
    const result = await saveScan(centerName, data);
    
    if (result.success) {
      setCurrentCount(p => p + 1);
      triggerFeedback("ثبت شد", "success");
    } else if (result.error === 'duplicate') {
      triggerFeedback("این کد تکراری است", "error");
    }

    setTimeout(() => setScanned(false), 1300);
  };

  const handleManualSubmit = () => {
    const finalString = `DK${mainCode}_${suffix}`;
    if (VALID_PATTERN.test(finalString)) {
      processScan(finalString);
      setMainCode("");
      setSuffix("");
      setManualVisible(false);
    } else {
      triggerFeedback("کد باید بصورت کامل وارد شود", "error");
    }
  };

  const renderMainGhostBoxes = () => {
    const boxes = [];
    for (let i = 0; i < 9; i++) {
      boxes.push(
        <View key={i} style={[styles.digitBox, mainCode[i] ? styles.digitBoxActive : null]}>
          <Text style={styles.digitText}>{toPersianNums(mainCode[i]) || ""}</Text>
        </View>
      );
    }
    return boxes;
  };

  if (!permission || !permission.granted) {
    return <View style={styles.container} />;
  }

  return (
    <View style={styles.container}>
      {/* 2. Freeze Prevention: Only render camera when screen is focused */}
      {isFocused && (
        <CameraView
          style={StyleSheet.absoluteFillObject}
          onBarcodeScanned={scanned || manualVisible ? undefined : ({ data }) => processScan(data)}
          barcodeScannerSettings={{ barcodeTypes: ["code128", "qr"] }}
        />
      )}

      {feedback.message !== '' && (
        <View style={[styles.feedbackToast, feedback.type === 'error' ? styles.toastError : styles.toastSuccess]}>
          <Text style={styles.toastText}>{feedback.message}</Text>
        </View>
      )}

      <View style={styles.topBar}>
        <View style={styles.infoBadge}>
          <Text numberOfLines={1} style={styles.infoText}>{centerName}</Text>
          <View style={styles.verticalDivider} />
          <Text style={styles.infoText}>{toPersianNums(currentCount)} کد</Text>
        </View>
      </View>

      <View style={styles.overlay}>
        <TouchableOpacity style={styles.manualButton} onPress={() => setManualVisible(true)}>
          <Ionicons name="keypad" size={22} color="#17479e" />
          <Text style={styles.btnTextStyle}>ورود دستی</Text>
        </TouchableOpacity>
        
        <TouchableOpacity style={styles.backButton} onPress={() => router.back()}>
          <Text style={[styles.btnTextStyle, { color: '#17479e' }]}>تایید و پایان</Text>
        </TouchableOpacity>
      </View>

      <Modal visible={manualVisible} animationType="fade" transparent={true}>
        <KeyboardAvoidingView 
          behavior={Platform.OS === "ios" ? "padding" : "height"}
          style={styles.modalContainer}
        >
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>ورود دستی کد سفارش</Text>
            
            <TouchableOpacity 
              activeOpacity={1} 
              onPress={() => inputRef.current?.focus()} 
              style={styles.visualizerContainer}
            >
              <Text style={styles.prefixText}>DK</Text>
              
              {/* Fixed 9 Boxes for Main Code */}
              <View style={styles.boxesRow}>{renderMainGhostBoxes()}</View>
              
              <Text style={styles.underscore}>_</Text>
              
              {/* Flexible Box for Suffix (1 or 2 digits) */}
              <View style={[styles.suffixBox, suffix ? styles.suffixBoxActive : null]}>
                <Text style={styles.digitText}>{toPersianNums(suffix)}</Text>
              </View>
            </TouchableOpacity>

            <TextInput
              ref={inputRef}
              style={styles.hiddenInput}
              keyboardType="number-pad"
              maxLength={11} // 9 digits + up to 2 suffix digits
              value={mainCode + suffix}
              onChangeText={(val) => {
                const clean = val.replace(/[^0-9]/g, '');
                if (clean.length <= 9) {
                  setMainCode(clean);
                  setSuffix("");
                } else {
                  setMainCode(clean.substring(0, 9));
                  setSuffix(clean.substring(9));
                }
              }}
              caretHidden={true}
            />

            <View style={styles.modalButtons}>
              <TouchableOpacity onPress={handleManualSubmit} style={styles.saveBtn}>
                <Text style={styles.saveBtnText}>ذخیره کد</Text>
              </TouchableOpacity>
              <TouchableOpacity 
                onPress={() => { setMainCode(""); setSuffix(""); setManualVisible(false); }} 
                style={styles.cancelBtn}
              >
                <Text style={styles.cancelBtnText}>انصراف</Text>
              </TouchableOpacity>
            </View>
          </View>
        </KeyboardAvoidingView>
      </Modal>
    </View>
  );
};

export default ScannerScreen;

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#000" },
  feedbackToast: { position: 'absolute', top: 140, alignSelf: 'center', paddingHorizontal: 30, paddingVertical: 10, borderRadius: 15, zIndex: 100 },
  toastSuccess: { backgroundColor: '#27ae60' },
  toastError: { backgroundColor: '#e74c3c' },
  toastText: { color: '#fff', fontFamily: 'IRANSans', fontSize: 18, textAlign: 'center' },
  topBar: { position: "absolute", top: 60, width: "100%", alignItems: "center", zIndex: 10 },
  infoBadge: { 
    flexDirection: 'row', 
    backgroundColor: 'rgba(23, 71, 158, 0.9)', 
    paddingVertical: 12, 
    paddingHorizontal: 20, 
    borderRadius: 25, 
    alignItems: 'center', 
    borderWidth: 1, 
    borderColor: '#f0b619', 
    maxWidth: '92%', 
    alignSelf: 'center',
    direction: 'ltr' 
  },
  infoText: { color: '#fff', fontFamily: 'IRANSans', fontSize: 18, textAlign: 'center' },
  verticalDivider: { width: 1, height: 20, backgroundColor: 'rgba(255,255,255,0.3)', marginHorizontal: 15 },
  overlay: { 
    position: "absolute", 
    bottom: 50, 
    width: "100%", 
    flexDirection: "row", 
    justifyContent: "center", 
    paddingHorizontal: 20, 
    gap: 12,
    direction: 'ltr'
  },
  manualButton: { flex: 1, backgroundColor: "#fff", height: 60, borderRadius: 18, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, elevation: 5 },
  backButton: { flex: 1, backgroundColor: "#f0b619", height: 60, borderRadius: 18, alignItems: 'center', justifyContent: 'center', elevation: 5 },
  btnTextStyle: { color: "#17479e", fontFamily: 'IRANSans', fontSize: 18, textAlign: 'center' },
  
  modalContainer: { 
    flex: 1, 
    justifyContent: "flex-start", 
    backgroundColor: "rgba(0,0,0,0.6)",
    paddingTop: 100 
  },
  modalContent: { 
    backgroundColor: "white", 
    borderRadius: 30, 
    marginHorizontal: 15,
    padding: 25, 
    alignItems: "center", 
    elevation: 20
  },
  modalTitle: { fontFamily: 'IRANSans', fontSize: 18, marginBottom: 25, color: "#7f8c8d" },
  visualizerContainer: { 
    flexDirection: "row", 
    alignItems: "center", 
    marginBottom: 35,
    direction: 'ltr'
  },
  prefixText: { fontSize: 24, fontFamily: 'IRANSans', color: "#2c3e50", marginRight: 10 },
  boxesRow: { flexDirection: "row", alignItems: "center" },
  digitBox: { width: 18, height: 40, borderBottomWidth: 2, borderColor: "#bdc3c7", marginHorizontal: 1.5, justifyContent: "center", alignItems: "center" },
  digitBoxActive: { borderColor: "#17479e" },
  digitText: { fontSize: 22, fontFamily: 'IRANSans', color: "#17479e" },
  underscore: { fontSize: 24, color: "#7f8c8d", marginHorizontal: 5 },
  // Flexible suffix box
  suffixBox: { minWidth: 40, height: 40, borderBottomWidth: 2, borderColor: "#bdc3c7", justifyContent: "center", alignItems: "center", paddingHorizontal: 5 },
  suffixBoxActive: { borderColor: "#f0b619" },
  
  hiddenInput: { position: "absolute", opacity: 0, width: 0, height: 0 }, 
  modalButtons: { 
    flexDirection: "row", 
    gap: 12, 
    width: "100%",
    direction: 'ltr'
  },
  saveBtn: { flex: 2, backgroundColor: "#17479e", padding: 18, borderRadius: 15, alignItems: "center" },
  saveBtnText: { color: "#fff", fontFamily: 'IRANSans', fontSize: 18 },
  cancelBtn: { flex: 1, backgroundColor: "#ecf0f1", padding: 18, borderRadius: 15, alignItems: "center" },
  cancelBtnText: { color: "#7f8c8d", fontFamily: 'IRANSans', fontSize: 16 },
});