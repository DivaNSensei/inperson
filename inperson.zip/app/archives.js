import React, { useState, useCallback } from 'react';
import { StyleSheet, Text, View, FlatList, TouchableOpacity, Platform } from 'react-native';
import { useFocusEffect, useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { getAllArchives, getTodayJalali, toPersianNums } from '../utils/storage'; 

export default function ArchivesScreen() {
  const [archives, setArchives] = useState({});
  const router = useRouter();

  useFocusEffect(
    useCallback(() => {
      loadData();
    }, [])
  );

  const loadData = async () => {
    const data = await getAllArchives();
    setArchives(data || {});
  };

  const handleAddNewArchive = () => {
    const baseDate = getTodayJalali();
    let finalKey = baseDate;
    let counter = 2;

    while (archives[finalKey]) {
      finalKey = `${baseDate} _${counter}`;
      counter++;
    }

    router.push({
      pathname: '/daily-session',
      params: { date: finalKey }
    });
  };

  const renderDay = ({ item: dateKey }) => {
    const centers = archives[dateKey];
    const totalScans = Object.values(centers).reduce((acc, curr) => acc + curr.length, 0);
    const activeCentersCount = Object.keys(centers).length;

    return (
      <TouchableOpacity 
        style={styles.dayCard}
        activeOpacity={0.8}
        onPress={() => router.push({ pathname: '/daily-session', params: { date: dateKey } })}
      >
        <View style={styles.cardHeader}>
          {/* Badge on left, Date on right */}
          <View style={styles.badgeContainer}>
             <Text style={styles.totalBadge}>{toPersianNums(totalScans)} کد</Text>
          </View>
          <Text style={styles.dateText}>{"\u200f" + toPersianNums(dateKey)}</Text>
        </View>
        
        <View style={styles.cardFooter}>
          <Ionicons name="chevron-back" size={24} color="#17479e" />
          <Text style={styles.previewText} numberOfLines={1}>
            {toPersianNums(activeCentersCount)} گنجه فعال: {Object.keys(centers).join(' - ')}
          </Text>
        </View>
      </TouchableOpacity>
    );
  };

  const dateKeys = Object.keys(archives).sort().reverse();

  return (
    <View style={styles.container}>
      {/* HEADER FIX: Absolute Positioning */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>آرشیوها</Text>
        
        <TouchableOpacity onPress={() => router.back()} style={styles.topRightBackButton}>
          <Ionicons name="chevron-forward" size={35} color="#fff" />
        </TouchableOpacity>
      </View>

      <FlatList
        data={dateKeys}
        renderItem={renderDay}
        keyExtractor={(item) => item}
        contentContainerStyle={styles.listContent}
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <Ionicons name="archive-outline" size={100} color="#dcdde1" />
            <Text style={styles.emptyText}>آرشیوی یافت نشد.</Text>
          </View>
        }
      />

      {/* FAB FIX: Hardcoded Right positioning */}
      <TouchableOpacity style={styles.fab} onPress={handleAddNewArchive}>
        <Ionicons name="add" size={45} color="#17479e" />
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f8f9fa' },
  header: { 
    height: 140,
    backgroundColor: '#17479e', 
    justifyContent: 'center', 
    alignItems: 'center', 
    paddingTop: 40,
    borderBottomRightRadius: 30,
    borderBottomLeftRadius: 30,
    elevation: 10,
    position: 'relative',
  },
  headerTitle: { fontSize: 28, fontFamily: 'IRANSans', color: '#fff' },
  topRightBackButton: { 
    position: 'absolute',
    right: 20,
    top: 65,
    padding: 5,
    zIndex: 10
  },
  listContent: { padding: 20, paddingBottom: 120 },
  dayCard: { 
    backgroundColor: '#fff', 
    borderRadius: 20, 
    padding: 22, 
    marginBottom: 18, 
    elevation: 4,
  },
  cardHeader: { 
    flexDirection: 'row', // Force LTR row
    justifyContent: 'space-between', 
    alignItems: 'center',
    borderBottomWidth: 1,
    borderBottomColor: '#f1f2f6',
    paddingBottom: 12,
    marginBottom: 12
  },
  dateText: { 
    fontSize: 24, 
    fontFamily: 'IRANSans', 
    color: '#17479e',
    textAlign: 'right'
  },
  badgeContainer: { 
    backgroundColor: '#f0b619', 
    paddingHorizontal: 12, 
    paddingVertical: 4, 
    borderRadius: 10 
  },
  totalBadge: { 
    color: '#17479e', 
    fontSize: 18, 
    fontFamily: 'IRANSans',
  },
  cardFooter: { 
    flexDirection: 'row', // Force LTR row
    justifyContent: 'space-between', 
    alignItems: 'center' 
  },
  previewText: { 
    color: '#7f8c8d', 
    fontSize: 16, 
    fontFamily: 'IRANSans', 
    textAlign: 'right', 
    flex: 1, 
    marginLeft: 10 
  },
  emptyContainer: { alignItems: 'center', marginTop: 100 },
  emptyText: { marginTop: 20, color: '#bdc3c7', fontSize: 20, fontFamily: 'IRANSans' },
  fab: {
    position: 'absolute',
    bottom: Platform.OS === 'android' ? 90 : 50,
    right: 30, // Stay on the right side
    backgroundColor: '#f0b619', 
    width: 75,
    height: 75,
    borderRadius: 37.5,
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 10,
  }
});