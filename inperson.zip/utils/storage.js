import AsyncStorage from '@react-native-async-storage/async-storage';
import { toJalaali } from 'jalaali-js';

const STORAGE_KEY = '@warehouse_archives';

export const toPersianNums = (str) => {
  if (str === null || str === undefined) return "";
  const persianDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
  return str.toString().replace(/\d/g, (x) => persianDigits[x]);
};

// 1. HELPER: Get Today's Date in Iranian Format (YYYY-MM-DD)
export const getTodayJalali = () => {
  const now = new Date();
  const j = toJalaali(now.getFullYear(), now.getMonth() + 1, now.getDate());
  // Ensures 1404-2-9 becomes 1404-02-09 for better sorting
  const pad = (n) => (n < 10 ? `0${n}` : n);
  return `${j.jy}-${pad(j.jm)}-${pad(j.jd)}`;
};

// 2. SAVE A SCAN
export const saveScan = async (centerName, scanCode) => {
  try {
    const today = getTodayJalali();
    const existingData = await AsyncStorage.getItem(STORAGE_KEY);
    const archives = existingData ? JSON.parse(existingData) : {};

    // Structure: archives -> "1404-11-20" -> "Pallet_A" -> [Array of codes]
    if (!archives[today]) archives[today] = {};
    if (!archives[today][centerName]) archives[today][centerName] = [];

    // Prevent duplicate scans in the same pallet
    if (archives[today][centerName].includes(scanCode)) {
      console.log("Duplicate ignored");
      return { success: false, error: 'duplicate' };
    }

    archives[today][centerName].push(scanCode);
    await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(archives));
    return { success: true };
  } catch (e) {
    console.error("Storage Error", e);
    return { success: false, error: 'system' };
  }
};

// 3. GET ALL DATA (For the Archive Screen)
export const getAllArchives = async () => {
  try {
    const data = await AsyncStorage.getItem(STORAGE_KEY);
    return data ? JSON.parse(data) : {};
  } catch (e) {
    return {};
  }
};

// DELETE A SPECIFIC CODE
export const deleteScan = async (date, centerName, codeToDelete) => {
  const data = await getAllArchives();
  if (data[date] && data[date][centerName]) {
    data[date][centerName] = data[date][centerName].filter(code => code !== codeToDelete);
    await AsyncStorage.setItem('@warehouse_archives', JSON.stringify(data));
    return { success: true };
  }
  return { success: false };
};